::

                                               ## 1.Data wrangling    

Q a. Ensure that the data is clean and free from any missing or incorrect entries.
----------------------------------------------------------------------------------

Inspect the data manually to identify missing or incorrect information using the functions isna() and notna().
--------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    import pandas as pd 

.. code:: ipython3

    df=pd.read_csv ('C:/Users/Bishnu/Desktop/Microsoft AI/Projects/AusApparalSales4thQrt2020.csv')

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Date</th>
          <th>Time</th>
          <th>State</th>
          <th>Group</th>
          <th>Unit</th>
          <th>Sales</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1-Oct-2020</td>
          <td>Morning</td>
          <td>WA</td>
          <td>Kids</td>
          <td>8</td>
          <td>20000</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1-Oct-2020</td>
          <td>Morning</td>
          <td>WA</td>
          <td>Men</td>
          <td>8</td>
          <td>20000</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1-Oct-2020</td>
          <td>Morning</td>
          <td>WA</td>
          <td>Women</td>
          <td>4</td>
          <td>10000</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1-Oct-2020</td>
          <td>Morning</td>
          <td>WA</td>
          <td>Seniors</td>
          <td>15</td>
          <td>37500</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1-Oct-2020</td>
          <td>Afternoon</td>
          <td>WA</td>
          <td>Kids</td>
          <td>3</td>
          <td>7500</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>7555</th>
          <td>30-Dec-2020</td>
          <td>Afternoon</td>
          <td>TAS</td>
          <td>Seniors</td>
          <td>14</td>
          <td>35000</td>
        </tr>
        <tr>
          <th>7556</th>
          <td>30-Dec-2020</td>
          <td>Evening</td>
          <td>TAS</td>
          <td>Kids</td>
          <td>15</td>
          <td>37500</td>
        </tr>
        <tr>
          <th>7557</th>
          <td>30-Dec-2020</td>
          <td>Evening</td>
          <td>TAS</td>
          <td>Men</td>
          <td>15</td>
          <td>37500</td>
        </tr>
        <tr>
          <th>7558</th>
          <td>30-Dec-2020</td>
          <td>Evening</td>
          <td>TAS</td>
          <td>Women</td>
          <td>11</td>
          <td>27500</td>
        </tr>
        <tr>
          <th>7559</th>
          <td>30-Dec-2020</td>
          <td>Evening</td>
          <td>TAS</td>
          <td>Seniors</td>
          <td>13</td>
          <td>32500</td>
        </tr>
      </tbody>
    </table>
    <p>7560 rows × 6 columns</p>
    </div>



.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7560 entries, 0 to 7559
    Data columns (total 6 columns):
     #   Column  Non-Null Count  Dtype 
    ---  ------  --------------  ----- 
     0   Date    7560 non-null   object
     1   Time    7560 non-null   object
     2   State   7560 non-null   object
     3   Group   7560 non-null   object
     4   Unit    7560 non-null   int64 
     5   Sales   7560 non-null   int64 
    dtypes: int64(2), object(4)
    memory usage: 354.5+ KB
    

.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unit</th>
          <th>Sales</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>7560.000000</td>
          <td>7560.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>18.005423</td>
          <td>45013.558201</td>
        </tr>
        <tr>
          <th>std</th>
          <td>12.901403</td>
          <td>32253.506944</td>
        </tr>
        <tr>
          <th>min</th>
          <td>2.000000</td>
          <td>5000.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>8.000000</td>
          <td>20000.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>14.000000</td>
          <td>35000.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>26.000000</td>
          <td>65000.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>65.000000</td>
          <td>162500.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.isna().sum()




.. parsed-literal::

    Date     0
    Time     0
    State    0
    Group    0
    Unit     0
    Sales    0
    dtype: int64



.. code:: ipython3

    df ['Date'].unique()




.. parsed-literal::

    array(['1-Oct-2020', '2-Oct-2020', '3-Oct-2020', '4-Oct-2020',
           '5-Oct-2020', '6-Oct-2020', '7-Oct-2020', '8-Oct-2020',
           '9-Oct-2020', '10-Oct-2020', '11-Oct-2020', '12-Oct-2020',
           '13-Oct-2020', '14-Oct-2020', '15-Oct-2020', '16-Oct-2020',
           '17-Oct-2020', '18-Oct-2020', '19-Oct-2020', '20-Oct-2020',
           '21-Oct-2020', '22-Oct-2020', '23-Oct-2020', '24-Oct-2020',
           '25-Oct-2020', '26-Oct-2020', '27-Oct-2020', '28-Oct-2020',
           '29-Oct-2020', '30-Oct-2020', '1-Nov-2020', '2-Nov-2020',
           '3-Nov-2020', '4-Nov-2020', '5-Nov-2020', '6-Nov-2020',
           '7-Nov-2020', '8-Nov-2020', '9-Nov-2020', '10-Nov-2020',
           '11-Nov-2020', '12-Nov-2020', '13-Nov-2020', '14-Nov-2020',
           '15-Nov-2020', '16-Nov-2020', '17-Nov-2020', '18-Nov-2020',
           '19-Nov-2020', '20-Nov-2020', '21-Nov-2020', '22-Nov-2020',
           '23-Nov-2020', '24-Nov-2020', '25-Nov-2020', '26-Nov-2020',
           '27-Nov-2020', '28-Nov-2020', '29-Nov-2020', '30-Nov-2020',
           '1-Dec-2020', '2-Dec-2020', '3-Dec-2020', '4-Dec-2020',
           '5-Dec-2020', '6-Dec-2020', '7-Dec-2020', '8-Dec-2020',
           '9-Dec-2020', '10-Dec-2020', '11-Dec-2020', '12-Dec-2020',
           '13-Dec-2020', '14-Dec-2020', '15-Dec-2020', '16-Dec-2020',
           '17-Dec-2020', '18-Dec-2020', '19-Dec-2020', '20-Dec-2020',
           '21-Dec-2020', '22-Dec-2020', '23-Dec-2020', '24-Dec-2020',
           '25-Dec-2020', '26-Dec-2020', '27-Dec-2020', '28-Dec-2020',
           '29-Dec-2020', '30-Dec-2020'], dtype=object)



.. code:: ipython3

    time_na_check=df.groupby('Date').agg({'Time':'nunique'})

.. code:: ipython3

    time_na_check




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Time</th>
        </tr>
        <tr>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1-Dec-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>1-Nov-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>1-Oct-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>10-Dec-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>10-Nov-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
        </tr>
        <tr>
          <th>8-Nov-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>8-Oct-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>9-Dec-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>9-Nov-2020</th>
          <td>3</td>
        </tr>
        <tr>
          <th>9-Oct-2020</th>
          <td>3</td>
        </tr>
      </tbody>
    </table>
    <p>90 rows × 1 columns</p>
    </div>



.. code:: ipython3

    time_na_check [time_na_check ['Time']<3]




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Time</th>
        </tr>
        <tr>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    ideal_dates=  [i.strftime('%d-%b-%y') for i in pd.date_range(start='01-Oct-2020', end='31-Dec-2020', freq='D')]

.. code:: ipython3

    ideal_dates




.. parsed-literal::

    ['01-Oct-20',
     '02-Oct-20',
     '03-Oct-20',
     '04-Oct-20',
     '05-Oct-20',
     '06-Oct-20',
     '07-Oct-20',
     '08-Oct-20',
     '09-Oct-20',
     '10-Oct-20',
     '11-Oct-20',
     '12-Oct-20',
     '13-Oct-20',
     '14-Oct-20',
     '15-Oct-20',
     '16-Oct-20',
     '17-Oct-20',
     '18-Oct-20',
     '19-Oct-20',
     '20-Oct-20',
     '21-Oct-20',
     '22-Oct-20',
     '23-Oct-20',
     '24-Oct-20',
     '25-Oct-20',
     '26-Oct-20',
     '27-Oct-20',
     '28-Oct-20',
     '29-Oct-20',
     '30-Oct-20',
     '31-Oct-20',
     '01-Nov-20',
     '02-Nov-20',
     '03-Nov-20',
     '04-Nov-20',
     '05-Nov-20',
     '06-Nov-20',
     '07-Nov-20',
     '08-Nov-20',
     '09-Nov-20',
     '10-Nov-20',
     '11-Nov-20',
     '12-Nov-20',
     '13-Nov-20',
     '14-Nov-20',
     '15-Nov-20',
     '16-Nov-20',
     '17-Nov-20',
     '18-Nov-20',
     '19-Nov-20',
     '20-Nov-20',
     '21-Nov-20',
     '22-Nov-20',
     '23-Nov-20',
     '24-Nov-20',
     '25-Nov-20',
     '26-Nov-20',
     '27-Nov-20',
     '28-Nov-20',
     '29-Nov-20',
     '30-Nov-20',
     '01-Dec-20',
     '02-Dec-20',
     '03-Dec-20',
     '04-Dec-20',
     '05-Dec-20',
     '06-Dec-20',
     '07-Dec-20',
     '08-Dec-20',
     '09-Dec-20',
     '10-Dec-20',
     '11-Dec-20',
     '12-Dec-20',
     '13-Dec-20',
     '14-Dec-20',
     '15-Dec-20',
     '16-Dec-20',
     '17-Dec-20',
     '18-Dec-20',
     '19-Dec-20',
     '20-Dec-20',
     '21-Dec-20',
     '22-Dec-20',
     '23-Dec-20',
     '24-Dec-20',
     '25-Dec-20',
     '26-Dec-20',
     '27-Dec-20',
     '28-Dec-20',
     '29-Dec-20',
     '30-Dec-20',
     '31-Dec-20']



.. code:: ipython3

    Data_dates= [i.strftime('%d-%b-%y') for i in pd.to_datetime(df['Date']).unique()]

.. code:: ipython3

    Data_dates




.. parsed-literal::

    ['01-Oct-20',
     '02-Oct-20',
     '03-Oct-20',
     '04-Oct-20',
     '05-Oct-20',
     '06-Oct-20',
     '07-Oct-20',
     '08-Oct-20',
     '09-Oct-20',
     '10-Oct-20',
     '11-Oct-20',
     '12-Oct-20',
     '13-Oct-20',
     '14-Oct-20',
     '15-Oct-20',
     '16-Oct-20',
     '17-Oct-20',
     '18-Oct-20',
     '19-Oct-20',
     '20-Oct-20',
     '21-Oct-20',
     '22-Oct-20',
     '23-Oct-20',
     '24-Oct-20',
     '25-Oct-20',
     '26-Oct-20',
     '27-Oct-20',
     '28-Oct-20',
     '29-Oct-20',
     '30-Oct-20',
     '01-Nov-20',
     '02-Nov-20',
     '03-Nov-20',
     '04-Nov-20',
     '05-Nov-20',
     '06-Nov-20',
     '07-Nov-20',
     '08-Nov-20',
     '09-Nov-20',
     '10-Nov-20',
     '11-Nov-20',
     '12-Nov-20',
     '13-Nov-20',
     '14-Nov-20',
     '15-Nov-20',
     '16-Nov-20',
     '17-Nov-20',
     '18-Nov-20',
     '19-Nov-20',
     '20-Nov-20',
     '21-Nov-20',
     '22-Nov-20',
     '23-Nov-20',
     '24-Nov-20',
     '25-Nov-20',
     '26-Nov-20',
     '27-Nov-20',
     '28-Nov-20',
     '29-Nov-20',
     '30-Nov-20',
     '01-Dec-20',
     '02-Dec-20',
     '03-Dec-20',
     '04-Dec-20',
     '05-Dec-20',
     '06-Dec-20',
     '07-Dec-20',
     '08-Dec-20',
     '09-Dec-20',
     '10-Dec-20',
     '11-Dec-20',
     '12-Dec-20',
     '13-Dec-20',
     '14-Dec-20',
     '15-Dec-20',
     '16-Dec-20',
     '17-Dec-20',
     '18-Dec-20',
     '19-Dec-20',
     '20-Dec-20',
     '21-Dec-20',
     '22-Dec-20',
     '23-Dec-20',
     '24-Dec-20',
     '25-Dec-20',
     '26-Dec-20',
     '27-Dec-20',
     '28-Dec-20',
     '29-Dec-20',
     '30-Dec-20']



.. code:: ipython3

    set(ideal_dates)-set(Data_dates)




.. parsed-literal::

    {'31-Dec-20', '31-Oct-20'}



Answer a: There are two missing dates
-------------------------------------

Q b.Based on your knowledge of data analytics, include your recommendations for treating missing and incorrect data (dropping the null values or filling them)
--------------------------------------------------------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    df.groupby('Date').agg({'Sales':'count'})




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Sales</th>
        </tr>
        <tr>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1-Dec-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>1-Nov-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>1-Oct-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>10-Dec-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>10-Nov-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
        </tr>
        <tr>
          <th>8-Nov-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>8-Oct-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>9-Dec-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>9-Nov-2020</th>
          <td>84</td>
        </tr>
        <tr>
          <th>9-Oct-2020</th>
          <td>84</td>
        </tr>
      </tbody>
    </table>
    <p>90 rows × 1 columns</p>
    </div>



Answer b: The amount of missing data is quite large (168 records). Therefore, it is not recommended to generate or impute data in this case, as the missing values are associated with the date field. Since the date variable is not being used as a feature in the algorithm, there is no need to fill in the missing data. However, if this were a time-series analysis and the selected algorithm required continuous observations over time, then filling the missing dates would be necessary to maintain the integrity of the dataset.
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    84*2




.. parsed-literal::

    168



Q d. Share your insights regarding the application of the GroupBy() function for either data chunking or merging, and offer a recommendation based on your analysis.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Answer d: The GroupBy operation is primarily used for data analysis and aggregation. It is not intended for chuncking or merging datasets. In this calculation GroupBy() function is used to summarize data by grouping records based on columns and applying aggregate functions such as count, sum, average, minimum, or maximum.
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

::

                                                         ## Data Analysis 

Q a. Perform descriptive statistical analysis on the data in the Sales and Unit columns. Utilize techniques such as mean, median, mode, and standard deviation for this analysis.
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unit</th>
          <th>Sales</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>7560.000000</td>
          <td>7560.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>18.005423</td>
          <td>45013.558201</td>
        </tr>
        <tr>
          <th>std</th>
          <td>12.901403</td>
          <td>32253.506944</td>
        </tr>
        <tr>
          <th>min</th>
          <td>2.000000</td>
          <td>5000.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>8.000000</td>
          <td>20000.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>14.000000</td>
          <td>35000.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>26.000000</td>
          <td>65000.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>65.000000</td>
          <td>162500.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    # Mode of Unit column
    print(df['Unit'].mode())
    
    # Mode of Sales column
    print(df['Sales'].mode())


.. parsed-literal::

    0    9
    Name: Unit, dtype: int64
    0    22500
    Name: Sales, dtype: int64
    

Q b.Identify the group with the highest sales and the group with the lowest sales based on the data provided.
-------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    df.groupby('Group').agg({'Sales':'sum'}).sort_values('Sales')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Sales</th>
        </tr>
        <tr>
          <th>Group</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Seniors</th>
          <td>84037500</td>
        </tr>
        <tr>
          <th>Kids</th>
          <td>85072500</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>85442500</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>85750000</td>
        </tr>
      </tbody>
    </table>
    </div>



d. Generate weekly, monthly, and quarterly reports to document and present the results of the analysis conducted
----------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    # Convert Date column to datetime
    df['Date'] = pd.to_datetime(df['Date'], format='%d-%b-%Y')
    
    # Check datatype
    print(df.dtypes)


.. parsed-literal::

    Date     datetime64[ns]
    Time             object
    State            object
    Group            object
    Unit              int64
    Sales             int64
    dtype: object
    

.. code:: ipython3

    weekly_report = df.resample('W', on='Date').agg({
        'Sales':['sum','mean','max','min'],
        'Unit':'sum'
    })
    
    weekly_report.columns = ['Total_Sales','Average_Sales','Max_Sales','Min_Sales','Total_Units']
    weekly_report = weekly_report.reset_index()
    
    print(weekly_report)


.. parsed-literal::

             Date  Total_Sales  Average_Sales  Max_Sales  Min_Sales  Total_Units
    0  2020-10-04     15045000   44776.785714     125000       7500         6018
    1  2020-10-11     27002500   45922.619048     125000       7500        10801
    2  2020-10-18     26640000   45306.122449     125000       7500        10656
    3  2020-10-25     26815000   45603.741497     125000       7500        10726
    4  2020-11-01     21807500   43268.849206     125000       5000         8723
    5  2020-11-08     20865000   35484.693878     112500       5000         8346
    6  2020-11-15     21172500   36007.653061     112500       5000         8469
    7  2020-11-22     21112500   35905.612245     112500       5000         8445
    8  2020-11-29     21477500   36526.360544     112500       5000         8591
    9  2020-12-06     29622500   50378.401361     162500       5000        11849
    10 2020-12-13     31525000   53613.945578     162500      12500        12610
    11 2020-12-20     31655000   53835.034014     162500      12500        12662
    12 2020-12-27     31770000   54030.612245     162500      12500        12708
    13 2021-01-03     13792500   54732.142857     162500      12500         5517
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    
    plt.figure(figsize=(12,6))
    
    sns.barplot(
        x='Date',
        y='Total_Sales',
        data=weekly_report,
        color='lightpink'
    )
    
    plt.title('Weekly Total Sales (Bar View)')
    plt.xticks(rotation=45)
    plt.ylabel('Total Sales')
    plt.xlabel('Week')
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.show()



.. image:: output_31_0.png


.. code:: ipython3

    monthly_report = df.resample('ME', on='Date').agg({
        'Sales':['sum','mean','max','min'],
        'Unit':'sum'
    })
    
    monthly_report.columns = ['Total_Sales','Average_Sales','Max_Sales','Min_Sales','Total_Units']
    monthly_report = monthly_report.reset_index()
    print(monthly_report)


.. parsed-literal::

            Date  Total_Sales  Average_Sales  Max_Sales  Min_Sales  Total_Units
    0 2020-10-31    114290000   45353.174603     125000       7500        45716
    1 2020-11-30     90682500   35985.119048     112500       5000        36273
    2 2020-12-31    135330000   53702.380952     162500      12500        54132
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    
    plt.figure(figsize=(6,4))
    
    sns.barplot(
        x='Date',
        y='Total_Sales',
        data=monthly_report,
        color='lightgreen'
    )
    
    plt.title('Month End Total Sales (Bar View)')
    plt.xticks(rotation=45)
    plt.ylabel('Total Sales')
    plt.xlabel('Month')
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.show()



.. image:: output_33_0.png


.. code:: ipython3

    quarterly_report = df.resample('QE', on='Date').agg({
        'Sales':['sum','mean','max','min'],
        'Unit':'sum'
    })
    
    quarterly_report.columns = ['Total_Sales','Average_Sales','Max_Sales','Min_Sales','Total_Units']
    quarterly_report = quarterly_report.reset_index()
    
    print(quarterly_report)


.. parsed-literal::

            Date  Total_Sales  Average_Sales  Max_Sales  Min_Sales  Total_Units
    0 2020-12-31    340302500   45013.558201     162500       5000       136121
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    
    plt.figure(figsize=(2.5,4))
    
    sns.barplot(
        x='Date',
        y='Total_Sales',
        data=quarterly_report,
        color='maroon'
    )
    
    plt.title('Quarter End Total Sales (Bar View)')
    plt.xticks(rotation=45)
    plt.ylabel('Total Sales')
    plt.xlabel('Quarter end date')
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.show()



.. image:: output_35_0.png


::

                                                    ##  3. Data visualization
                                                    

State-wise sales analysis for different demographic groups (kids, women, men, and seniors).
-------------------------------------------------------------------------------------------

.. code:: ipython3

    df.groupby(['State', 'Group']).agg({'Sales':'sum'})




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th></th>
          <th>Sales</th>
        </tr>
        <tr>
          <th>State</th>
          <th>Group</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th rowspan="4" valign="top">NSW</th>
          <th>Kids</th>
          <td>18587500</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>19022500</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>18187500</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>19172500</td>
        </tr>
        <tr>
          <th rowspan="4" valign="top">NT</th>
          <th>Kids</th>
          <td>5700000</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>5762500</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>5465000</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>5652500</td>
        </tr>
        <tr>
          <th rowspan="4" valign="top">QLD</th>
          <th>Kids</th>
          <td>8510000</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>8392500</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>8190000</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>8325000</td>
        </tr>
        <tr>
          <th rowspan="4" valign="top">SA</th>
          <th>Kids</th>
          <td>14515000</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>14655000</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>14717500</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>14970000</td>
        </tr>
        <tr>
          <th rowspan="4" valign="top">TAS</th>
          <th>Kids</th>
          <td>5775000</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>5757500</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>5650000</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>5577500</td>
        </tr>
        <tr>
          <th rowspan="4" valign="top">VIC</th>
          <th>Kids</th>
          <td>26360000</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>26407500</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>26315000</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>26482500</td>
        </tr>
        <tr>
          <th rowspan="4" valign="top">WA</th>
          <th>Kids</th>
          <td>5625000</td>
        </tr>
        <tr>
          <th>Men</th>
          <td>5752500</td>
        </tr>
        <tr>
          <th>Seniors</th>
          <td>5512500</td>
        </tr>
        <tr>
          <th>Women</th>
          <td>5262500</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.pivot_table(columns= ['Group'],index=['State'],aggfunc='sum', values='Sales')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th>Group</th>
          <th>Kids</th>
          <th>Men</th>
          <th>Seniors</th>
          <th>Women</th>
        </tr>
        <tr>
          <th>State</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>NSW</th>
          <td>18587500</td>
          <td>19022500</td>
          <td>18187500</td>
          <td>19172500</td>
        </tr>
        <tr>
          <th>NT</th>
          <td>5700000</td>
          <td>5762500</td>
          <td>5465000</td>
          <td>5652500</td>
        </tr>
        <tr>
          <th>QLD</th>
          <td>8510000</td>
          <td>8392500</td>
          <td>8190000</td>
          <td>8325000</td>
        </tr>
        <tr>
          <th>SA</th>
          <td>14515000</td>
          <td>14655000</td>
          <td>14717500</td>
          <td>14970000</td>
        </tr>
        <tr>
          <th>TAS</th>
          <td>5775000</td>
          <td>5757500</td>
          <td>5650000</td>
          <td>5577500</td>
        </tr>
        <tr>
          <th>VIC</th>
          <td>26360000</td>
          <td>26407500</td>
          <td>26315000</td>
          <td>26482500</td>
        </tr>
        <tr>
          <th>WA</th>
          <td>5625000</td>
          <td>5752500</td>
          <td>5512500</td>
          <td>5262500</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.pivot_table(columns= ['Group'],index=['State'],aggfunc='sum', values='Sales').plot(kind='bar')




.. parsed-literal::

    <Axes: xlabel='State'>




.. image:: output_39_1.png


Group-wise sales analysis (Kids, Women, Men, and Seniors) across various states.
--------------------------------------------------------------------------------

.. code:: ipython3

    df.groupby(['Group','State']).agg({'Sales':'sum'})




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th></th>
          <th>Sales</th>
        </tr>
        <tr>
          <th>Group</th>
          <th>State</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th rowspan="7" valign="top">Kids</th>
          <th>NSW</th>
          <td>18587500</td>
        </tr>
        <tr>
          <th>NT</th>
          <td>5700000</td>
        </tr>
        <tr>
          <th>QLD</th>
          <td>8510000</td>
        </tr>
        <tr>
          <th>SA</th>
          <td>14515000</td>
        </tr>
        <tr>
          <th>TAS</th>
          <td>5775000</td>
        </tr>
        <tr>
          <th>VIC</th>
          <td>26360000</td>
        </tr>
        <tr>
          <th>WA</th>
          <td>5625000</td>
        </tr>
        <tr>
          <th rowspan="7" valign="top">Men</th>
          <th>NSW</th>
          <td>19022500</td>
        </tr>
        <tr>
          <th>NT</th>
          <td>5762500</td>
        </tr>
        <tr>
          <th>QLD</th>
          <td>8392500</td>
        </tr>
        <tr>
          <th>SA</th>
          <td>14655000</td>
        </tr>
        <tr>
          <th>TAS</th>
          <td>5757500</td>
        </tr>
        <tr>
          <th>VIC</th>
          <td>26407500</td>
        </tr>
        <tr>
          <th>WA</th>
          <td>5752500</td>
        </tr>
        <tr>
          <th rowspan="7" valign="top">Seniors</th>
          <th>NSW</th>
          <td>18187500</td>
        </tr>
        <tr>
          <th>NT</th>
          <td>5465000</td>
        </tr>
        <tr>
          <th>QLD</th>
          <td>8190000</td>
        </tr>
        <tr>
          <th>SA</th>
          <td>14717500</td>
        </tr>
        <tr>
          <th>TAS</th>
          <td>5650000</td>
        </tr>
        <tr>
          <th>VIC</th>
          <td>26315000</td>
        </tr>
        <tr>
          <th>WA</th>
          <td>5512500</td>
        </tr>
        <tr>
          <th rowspan="7" valign="top">Women</th>
          <th>NSW</th>
          <td>19172500</td>
        </tr>
        <tr>
          <th>NT</th>
          <td>5652500</td>
        </tr>
        <tr>
          <th>QLD</th>
          <td>8325000</td>
        </tr>
        <tr>
          <th>SA</th>
          <td>14970000</td>
        </tr>
        <tr>
          <th>TAS</th>
          <td>5577500</td>
        </tr>
        <tr>
          <th>VIC</th>
          <td>26482500</td>
        </tr>
        <tr>
          <th>WA</th>
          <td>5262500</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.pivot_table(columns= ['State'],index=['Group'],aggfunc='sum', values='Sales').plot(kind='bar')




.. parsed-literal::

    <Axes: xlabel='Group'>




.. image:: output_42_1.png


Time-of-the-day analysis Identify peak and off-peak sales periods to facilitate strategic planning for S&M teams. This information aids in designing programs like hyper-personalization and Next Best Offers to enhance sales.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

.. code:: ipython3

    print(df['Time'].unique())


.. parsed-literal::

    [' Morning' ' Afternoon' ' Evening']
    

.. code:: ipython3

    # Remove extra spaces
    df['Time'] = df['Time'].str.strip()
    
    # Create the analysis table
    time_analysis = df.groupby('Time').agg(
        Total_Sales=('Sales', 'sum'),
        Average_Sales=('Sales', 'mean'),
        Total_Units=('Unit', 'sum'),
        Transactions=('Sales', 'count')
    ).reset_index()
    
    # Display the table
    print(time_analysis)


.. parsed-literal::

            Time  Total_Sales  Average_Sales  Total_Units  Transactions
    0  Afternoon    114007500   45241.071429        45603          2520
    1    Evening    112087500   44479.166667        44835          2520
    2    Morning    114207500   45320.436508        45683          2520
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Find peak and off-peak periods
    peak_period = time_analysis.loc[time_analysis['Total_Sales'].idxmax(), 'Time']
    off_peak_period = time_analysis.loc[time_analysis['Total_Sales'].idxmin(), 'Time']
    
    # Assign colors
    colors = ['steelblue'] * len(time_analysis)
    colors[time_analysis['Total_Sales'].idxmax()] = 'green'   # Peak
    colors[time_analysis['Total_Sales'].idxmin()] = 'red'     # Off-Peak
    
    # Plot
    plt.figure(figsize=(8,5))
    bars = plt.bar(time_analysis['Time'], time_analysis['Total_Sales'], color=colors)
    
    # Add value labels
    for bar in bars:
        plt.text(
            bar.get_x() + bar.get_width()/2,
            bar.get_height(),
            f"{bar.get_height():,.0f}",
            ha='center',
            va='bottom',
            fontsize=10
        )
    
    plt.title('Peak and Off-Peak Sales Periods')
    plt.xlabel('Time of Day')
    plt.ylabel('Total Sales')
    
    # Legend
    plt.scatter([], [], color='green', label=f'Peak: {peak_period}')
    plt.scatter([], [], color='red', label=f'Off-Peak: {off_peak_period}')
    plt.legend()
    
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    plt.show()



.. image:: output_46_0.png


